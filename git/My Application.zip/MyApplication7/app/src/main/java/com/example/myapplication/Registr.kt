package com.example.myapplication

class Registr {
}